﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppRegistroMultas.Contexto;
using AppRegistroMultas.Formulario;
using AppRegistroMultas.Models;
namespace AppRegistroMultas.Formulario
{
    public partial class FormConsultaVeiculo : Form
    {
        List<Veiculo> veiculo = new List<Veiculo>();
        List<Multa> itens = new List<Multa>();
        int cont = 1;

        public FormConsultaVeiculo()
        {
            InitializeComponent();
            veiculo = Context.ListaVeiculos.ToList();

            cbVeiculo.DataSource = veiculo.ToList();
            cbVeiculo.DisplayMember = "Placa";
            cbVeiculo.SelectedIndex = -1;
        }

        private void cbVeiculo_SelectedIndexChanged(object sender, EventArgs e)
        {
            var linhaSelec = cbVeiculo.SelectedIndex;

            if (linhaSelec > -1 && cont > 1)
            {
                var veiculos = veiculo[linhaSelec];
                txtModelo.Text = veiculos.Modelo;
                txtPlaca.Text = veiculos.Placa;
                txtAno.Text = veiculos.Ano.ToString();
                txtMarca.Text = veiculos.Marca;
                //master detalhe             
                dtTabela.DataSource = itens;
            }
            cont++;
        }
    }
}
