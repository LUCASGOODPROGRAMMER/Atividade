﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppRegistroMultas.Formulario;
using AppRegistroMultas.Models;
using AppRegistroMultas.Contexto;

namespace AppRegistroMultas.Formulario
{
    public partial class FormCadastro : Form
    {
        public Veiculo veiculo = new Veiculo();
        public Multa multa { get; set; }
        public List<Multa> itens = new List<Multa>();
        

        public FormCadastro()
        {
            InitializeComponent();
        }

        private void btSalvar_Click(object sender, EventArgs e)
        {
            veiculo = new Veiculo();
           
            veiculo.Placa = txtPlaca.Text;
            veiculo.Marca = txtMarca.Text;
            veiculo.Ano = Convert.ToInt32(txtAno.Text);
            veiculo.Modelo = txtModelo.Text;

            Context.ListaVeiculos.Add(veiculo);
            Context.ListaMultas.AddRange(itens);
            MessageBox.Show("SALVO COM SUCESSO!",
                "2° A INF", MessageBoxButtons.OK, MessageBoxIcon.Information);
          

            txtAno.Clear();
            txtMarca.Clear();
            txtModelo.Clear();
            txtPlaca.Clear();
            txtModelo.Select();
        }

       
    }
}
