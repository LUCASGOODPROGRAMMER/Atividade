﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppRegistroMultas.Contexto;
using AppRegistroMultas.Models;

namespace AppRegistroMultas.Formulario
{
    public partial class FormCadastroMulta : Form
    {
        Veiculo veiculos = new Veiculo();
        List<Veiculo> veiculo = new List<Veiculo>();
        public Multa multa { get; set; }
        List<Multa> itens = new List<Multa>();      
       
        static int IdVeiculo = 1;
        static int IdItem = 1;
        int cont = 1;

        public FormCadastroMulta()
        {
            InitializeComponent();
            veiculo = Context.ListaVeiculos.ToList();
           
            cbVeiculo.DataSource = veiculo.ToList();
            cbVeiculo.DisplayMember = "Placa";
            cbVeiculo.SelectedIndex = -1;
        }

        private void cbVeiculo_SelectedIndexChanged(object sender, EventArgs e)
        {
            var linhaSelec = cbVeiculo.SelectedIndex;

            if (linhaSelec > -1 && cont > 1)
            {
                var veiculos = veiculo[linhaSelec];
                txtModelo.Text = veiculos.Modelo;
                txtPlaca.Text = veiculos.Placa;
                txtAno.Text = veiculos.Ano.ToString();
                txtMarca.Text = veiculos.Marca;
                //master detalhe             

            }
            cont++;
        }

        private void dtTabela_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btAdd_Click(object sender, EventArgs e)
        {
            Multa multas = new Multa();
            multas.Descricao = txtDescricao.Text;
            multas.Valor = Convert.ToDouble(txtValor.Text);
            multas.IdVeiculo = IdVeiculo;
            multas.Id = IdItem;
            itens.Add(multas);
            
            
            IdItem++;
            IdVeiculo++;

            dtTabela.DataSource = itens.ToList();
        }

        private void btCancelar_Click(object sender, EventArgs e)
        {
            txtAno.Clear(); txtModelo.Clear(); txtPlaca.Clear(); txtMarca.Clear(); txtDescricao.Clear(); txtValor.Clear(); itens.Clear();
            dtTabela.DataSource = itens.ToList();
        }

        private void btSalvar_Click(object sender, EventArgs e)
        {
            
            veiculos = new Veiculo();
            multa = new Multa();
            veiculos.Placa = txtPlaca.Text;
            veiculos.Marca = txtMarca.Text;
            veiculos.Modelo = txtModelo.Text;
            veiculos.Id = IdVeiculo;
            multa.Descricao = txtDescricao.Text;
            multa.Valor = Convert.ToDouble(txtValor.Text);

            Context.ListaVeiculos.Add(veiculos);
           
            Context.ListaMultas.AddRange(itens);

            IdVeiculo++;

            

        }
    }
}
