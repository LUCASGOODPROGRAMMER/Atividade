﻿using AppRegistroMultas.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppRegistroMultas.Contexto
{
    public class Context
    {
        public static List<Veiculo> ListaVeiculos= new List<Veiculo>();
        public static List<Multa> ListaMultas = new List<Multa>();
    }
}
