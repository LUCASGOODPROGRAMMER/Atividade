﻿using AppRegistroMultas.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppRegistroMultas.Contexto;

namespace AppRegistroMultas.Formulario
{
    public partial class FormCadastroMulta : Form
    {
        List<Veiculo> veiculo = new List<Veiculo>();
        List<Multa> itens = new List<Multa>();
        int cont = 1;

        public FormCadastroMulta()
        {
            InitializeComponent();
            veiculo = Context.ListaVeiculos.ToList();
           
            cbVeiculo.DataSource = veiculo.ToList();
            cbVeiculo.DisplayMember = "NumeroPedido";
            cbVeiculo.SelectedIndex = -1;
        }

        private void cbVeiculo_SelectedIndexChanged(object sender, EventArgs e)
        {
            int linhaSelec = cbVeiculo.SelectedIndex;

            if (linhaSelec > -1 && cont > 1)
            {
                var veiculos = veiculo[linhaSelec];
                txtPlaca.Text = veiculos.Placa;
                txtModelo.Text = veiculos.Modelo;
                txtAno.Text = veiculos.Ano.ToString();
                txtMarca.Text = veiculos.Marca; 
                //master detalhe
                var itensDetalhe = itens.Where(i => i.Id == veiculos.Id).ToList();
                dtTabela.DataSource = itensDetalhe.ToList();              
                
            }
            cont++;
        }
    }
}
